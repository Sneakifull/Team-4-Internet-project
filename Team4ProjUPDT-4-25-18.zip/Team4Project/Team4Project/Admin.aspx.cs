﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Team4Project
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdminSubmit_Click(object sender, EventArgs e)
        {
            if (IsValidUser(txtAdminLog.Text.Trim(), txtAdminPass.Text.Trim()))
            {
                Session["Admin_Username"] = txtAdminLog.Text;
                Session["Type"] = "AdminType";

                Response.Redirect("Home.aspx");
            }
            else
            {
                // say Invalid Username or Password , please try again.
                rfvAdminLogin.ErrorMessage = "oof. Invalid Login";
                rfvAdminLogin.IsValid = false;
                rfvAdminpass.ErrorMessage = "oof. Invalid Password";
                rfvAdminpass.IsValid = false;

            }
    
        }
        /*
        private void SessionHandle(string username)
        {
            SqlConnection dB = new SqlConnection(SqlDataSource1.ConnectionString);
            SqlCommand sqlCommand = new SqlCommand("SELECT* FROM AdminInfo WHERE Admin_Username=@Username", dB);
            sqlCommand.Parameters.Add(new SqlParameter("@Username", username));
            SqlDataReader rdr = null;


        }
        */
        private bool IsValidUser(string username, string passWord)
        {
            bool loginSuccessful = false;

            SqlConnection dB = new SqlConnection(SqlDataSource1.ConnectionString);
            SqlCommand sqlCommand = new SqlCommand("SELECT* FROM AdminInfo WHERE Admin_Username=@Username AND Admin_Password=@Password", dB);
            sqlCommand.Parameters.Add(new SqlParameter("@Username", username));
            sqlCommand.Parameters.Add(new SqlParameter("@Password", passWord));
            SqlDataReader rdr = null;

            dB.Open();

            try
            {
                rdr = sqlCommand.ExecuteReader();

                if (rdr.HasRows)
                {
                    loginSuccessful = true;
                    return loginSuccessful;
                }
            }
            catch
            {

            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }

                // close the connection
                if (dB != null)
                {
                    dB.Close();
                }

            }
            return loginSuccessful;
        }
    }
}