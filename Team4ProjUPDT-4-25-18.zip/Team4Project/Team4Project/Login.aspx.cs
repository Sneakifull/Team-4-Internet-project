﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Team4Project
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {


            if (IsValidUser(txtEmail.Text.Trim(), txtPasword.Text.Trim()))
            {
                Session["Email"] = txtEmail.Text;
                Response.Redirect("Home.aspx");
            }
            else
            {
                // say Invalid Username or Password , please try again.
                rfvEmail.ErrorMessage = "oof. Invalid Email";
                rfvEmail.IsValid = false;
                rfvPassword.ErrorMessage = "oof. Invalid Password";
                rfvPassword.IsValid = false;
                
            }



        }
        /*
        protected bool usernameCheck(string email)
        {
            SqlConnection dB = new SqlConnection(SqlDataSource1.ConnectionString);
            SqlCommand cmd = new SqlCommand("SELECT * FROM UserInfo", dB);
            SqlDataReader rdr = null;


            dB.Open();

            try
            {
                rdr = cmd.ExecuteReader();
                

                while (rdr.Read())
                {
                    string temp = (String)rdr["UserEmail"];

                    if (temp.Equals(email))
                    {
                        return true;
                    }
                }


            }
            catch
            {

            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }

                // close the connection
                if (dB != null)
                {
                    dB.Close();
                }

            }

            return false;
        }
        */
        private bool IsValidUser(string email, string passWord)
        {
            bool loginSuccessful = false;

            SqlConnection dB = new SqlConnection(SqlDataSource1.ConnectionString);
            SqlCommand sqlCommand = new SqlCommand("SELECT* FROM UserInfo WHERE UserEmail=@User_Email AND User_Password=@Password", dB);
            sqlCommand.Parameters.Add(new SqlParameter("@UserEmail", email));
            sqlCommand.Parameters.Add(new SqlParameter("@Password", passWord));
            SqlDataReader rdr = null;

            dB.Open();

            try
            {
                rdr = sqlCommand.ExecuteReader();

                if (rdr.HasRows)
                {
                    loginSuccessful = true;
                    return loginSuccessful;
                }
            }
            catch
            {

            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }

                // close the connection
                if (dB != null)
                {
                    dB.Close();
                }

            }
            return loginSuccessful;
        }
    }
}